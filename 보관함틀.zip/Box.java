package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Box extends AppCompatActivity {

    int i;
    Button[] list;
    Button[] list_delete;
    boolean delete_check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_box);
        delete_check=false;

        list=new Button[3];
        list[0] = findViewById(R.id.list1);
        list[1] = findViewById(R.id.list2);
        list[2] = findViewById(R.id.list3);
        list_delete=new Button[3];
        list_delete[0] = findViewById(R.id.list1_delete);
        list_delete[1] = findViewById(R.id.list2_delete);
        list_delete[2] = findViewById(R.id.list3_delete);
        final AlertDialog.Builder bulider=new AlertDialog.Builder(Box.this);
        final AlertDialog.Builder bulider2=new AlertDialog.Builder(Box.this);
        final AlertDialog.Builder bulider3=new AlertDialog.Builder(Box.this);
        bulider.setMessage("삭제 하시겠습니까?.").setNegativeButton("아니오",null);
        bulider.setPositiveButton("예",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                delete_check=true;
                bulider2.create().show();
            }
        } );
        bulider2.setMessage("삭제하려면 다시 눌러주세요.");
        bulider3.setMessage("삭제 되었습니다.");
        for( i=0;i<list.length;i++) {
            list[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(view.getId()==R.id.list1){
                        if(list_delete[0].getVisibility()==view.VISIBLE){}
                    //리스트로 이동
                        else{
                            list_delete[0].setVisibility(view.VISIBLE);

                    //리스트 추가로 넘어감
                            //if(추가 되면)
                            list[0].setText("리스트 1");
                        }
                    }
                    else if(view.getId()==R.id.list2){
                        if(list_delete[1].getVisibility()==view.VISIBLE){}
                            //리스트로 이동
                        else {
                                list_delete[1].setVisibility(view.VISIBLE);

                                //리스트 추가로 넘어감
                            //if(추가 되면)
                            list[1].setText("리스트 2");
                            }
                    }
                    else{
                        if(list_delete[2].getVisibility()==view.VISIBLE){}
                            //리스트로 이동
                         else {
                                list_delete[2].setVisibility(view.VISIBLE);

                                //리스트 추가로 넘어감
                            //if(추가 되면)
                            list[2].setText("리스트 3");
                            }
                    }
                }
            });

            list_delete[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(delete_check==false)
                        bulider.create().show();
                    if(view.getId()==R.id.list1_delete){


                        if(delete_check==true){
                            list_delete[0].setVisibility(view.INVISIBLE);
                            //리스트 삭제
                            list[0].setText("리스트 추가");
                            bulider3.create().show();
                            delete_check=false;

                        }
                        //=true;

                    }
                   else if(view.getId()==R.id.list2_delete){

                        if(delete_check==true){
                            list_delete[1].setVisibility(view.INVISIBLE);
                             //리스트 삭제
                              list[1].setText("리스트 추가");
                            bulider3.create().show();
                            delete_check=false;

                        }
                    }
                    else {


                        if(delete_check==true){
                            list_delete[2].setVisibility(view.INVISIBLE);
                            //리스트 삭제
                             list[2].setText("리스트 추가");
                            bulider3.create().show();
                            delete_check=false;

                        }
                    }

                }
            });
        }
    }
}
